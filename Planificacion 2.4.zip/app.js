/* ============================================================
   PlanificaPlanta — app.js
   Vanilla JS — Google Apps Script integration
   ============================================================ */

'use strict';

// ============================================================
// CONFIG
// ============================================================
const CONFIG_KEY = 'planificaplanta_script_url';
const TOKEN_KEY   = 'planificaplanta_access_token';
const DAYS_ORDER = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];

let allTasks = [];
let allColaboradores = []; // Lista maestra { nombre, puesto } cargada desde la hoja "Colaboradores"
let selectedPriority = null;
let scriptUrl   = localStorage.getItem(CONFIG_KEY) || '';
let accessToken = localStorage.getItem(TOKEN_KEY) || '';
let pendingPayload = null; // Para guardar la tarea pausada por sobrecarga de horas

/**
 * Agrega el token de acceso a una URL de GET como query param.
 */
function withToken(url) {
  const sep = url.includes('?') ? '&' : '?';
  return `${url}${sep}token=${encodeURIComponent(accessToken)}`;
}

// ============================================================
// INIT
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
  initClock();
  initWeekBadge();
  initForm();
  initCharCounter();
  initDeleteHandler();

  if (!scriptUrl || !accessToken) {
    showConfigModal();
  } else {
    loadColaboradores();
    loadTasks();
  }
});

// ============================================================
// DELETE — Eliminar tarea (delegación de eventos sobre el tablero)
// ============================================================
function initDeleteHandler() {
  const board = document.getElementById('boardContent');
  board.addEventListener('click', (e) => {
    const btn = e.target.closest('.task-delete-btn');
    if (!btn) return;
    deleteTaskItem(btn.dataset.id);
  });
}

async function deleteTaskItem(id) {
  if (!id) return;
  if (!confirm('¿Eliminar esta actividad? Esta acción no se puede deshacer.')) return;

  try {
    const res  = await fetch(scriptUrl, {
      method:  'POST',
      headers: { 'Content-Type': 'text/plain' },
      body:    JSON.stringify({ action: 'delete', token: accessToken, id }),
    });
    const json = await res.json();

    if (json.status === 'ok') {
      showToast('🗑️ Actividad eliminada.', 'success');
      loadTasks();
    } else {
      throw new Error(json.message || 'Error al eliminar la actividad.');
    }
  } catch (err) {
    console.error(err);
    showToast(`❌ No se pudo eliminar: ${err.message}`, 'error');
  }
}

// ============================================================
// CLOCK & DATE UTILITIES
// ============================================================
function initClock() {
  const el = document.getElementById('headerTime');
  function tick() {
    const now = new Date();
    el.textContent = now.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }
  tick();
  setInterval(tick, 1000);
}

function initWeekBadge() {
  const badge = document.getElementById('weekBadge');
  const now = new Date();
  const day = now.getDay(); // 0=Sun
  const diffToMon = (day === 0) ? -6 : 1 - day;
  const mon = new Date(now);
  mon.setDate(now.getDate() + diffToMon);
  const sun = new Date(mon);
  sun.setDate(mon.getDate() + 6);
  const fmt = (d) => d.toLocaleDateString('es-ES', { day: '2-digit', month: 'short' });
  badge.textContent = `Semana: ${fmt(mon)} – ${fmt(sun)}`;
}

function getTodayName() {
  const days = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
  return days[new Date().getDay()];
}

// ============================================================
// TAB SWITCHING
// ============================================================
function switchTab(tab) {
  const panels = document.querySelectorAll('.tab-panel');
  const btns   = document.querySelectorAll('.tab-btn');
  panels.forEach(p => p.classList.remove('active'));
  btns.forEach(b => { b.classList.remove('active'); b.setAttribute('aria-selected', 'false'); });

  document.getElementById(`tab-${tab}`).classList.add('active');
  const btn = document.getElementById(`tab-${tab}-btn`);
  btn.classList.add('active');
  btn.setAttribute('aria-selected', 'true');

  if (tab === 'board' && scriptUrl) loadTasks();
}

// ============================================================
// FORM INIT & PRIORITY SELECTOR
// ============================================================
function initForm() {
  const form = document.getElementById('planForm');
  form.addEventListener('submit', handleSubmit);

  // Priority buttons
  document.querySelectorAll('.priority-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.priority-btn').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      selectedPriority = btn.dataset.value;
      document.getElementById('prioridad').value = selectedPriority;
      // Clear priority error
      document.getElementById('prioridad').closest('.field-group').classList.remove('has-error');
    });
  });
}

function initCharCounter() {
  const textarea = document.getElementById('actividad');
  const counter  = document.getElementById('charCount');
  textarea.addEventListener('input', () => {
    counter.textContent = textarea.value.length;
  });
}

// ============================================================
// FORM VALIDATION
// ============================================================
function validateForm() {
  let valid = true;
  const fields = [
    { id: 'area',           errId: 'area-error' },
    { id: 'actividad',      errId: 'actividad-error' },
    { id: 'dia',            errId: 'dia-error' },
    { id: 'prioridad',      errId: 'prioridad-error' },
    { id: 'colaborador',    errId: 'colaborador-error' },
  ];

  fields.forEach(f => {
    const el  = document.getElementById(f.id);
    const grp = el.closest('.field-group');
    if (!el.value.trim()) {
      grp.classList.add('has-error');
      valid = false;
    } else {
      grp.classList.remove('has-error');
    }
  });

  // Validate duration (both selects must have a value)
  const hEl  = document.getElementById('duracionHoras');
  const mEl  = document.getElementById('duracionMinutos');
  const dGrp = hEl.closest('.field-group');
  if (!hEl.value.trim() || !mEl.value.trim()) {
    dGrp.classList.add('has-error');
    valid = false;
  } else {
    dGrp.classList.remove('has-error');
  }

  return valid;
}

// ============================================================
// LOAD COLABORADORES — GET from Apps Script
// ============================================================
async function loadColaboradores() {
  if (!scriptUrl) return;
  const sel     = document.getElementById('colaborador');
  const arrow   = document.getElementById('colaboradorArrow');

  try {
    const res  = await fetch(withToken(`${scriptUrl}?action=colaboradores`), { method: 'GET' });
    const json = await res.json();

    if (json.status === 'ok' && json.data && json.data.length > 0) {
      // Normalizar a objetos { nombre, puesto } y guardar como lista maestra
      allColaboradores = json.data.map(item =>
        typeof item === 'string' ? { nombre: item, puesto: '' } : item
      );

      sel.innerHTML = '<option value="" disabled selected>Seleccione un colaborador...</option>';
      allColaboradores.forEach(item => {
        const opt = document.createElement('option');
        opt.value       = item.nombre;
        opt.textContent = item.puesto ? `${item.nombre} — ${item.puesto}` : item.nombre;
        sel.appendChild(opt);
      });

      sel.disabled   = false;
      arrow.innerHTML = '▾';
      populateColaboradorFilter();
    } else if (json.status === 'error') {
      throw new Error(json.message);
    } else {
      allColaboradores = [];
      sel.innerHTML   = '<option value="" disabled selected>Sin colaboradores registrados</option>';
      sel.disabled    = false;
      arrow.innerHTML = '▾';
      showToast('ℹ️ La hoja "Colaboradores" está vacía.', 'info');
    }
  } catch (err) {
    console.error('Error cargando colaboradores:', err);
    sel.innerHTML   = `<option value="" disabled selected>Error: ${err.message}</option>`;
    sel.disabled    = false;
    arrow.innerHTML = '▾';
    showToast(`❌ No se pudo cargar la lista de colaboradores: ${err.message}`, 'error');
  }
}

/**
 * Llena el <select> del filtro por colaborador en el tablero, usando
 * la lista maestra cargada desde la hoja "Colaboradores".
 */
function populateColaboradorFilter() {
  const filterSel = document.getElementById('filterColaborador');
  if (!filterSel) return;
  const current = filterSel.value;

  filterSel.innerHTML = '<option value="">Todos los colaboradores</option>';
  allColaboradores
    .slice()
    .sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'))
    .forEach(item => {
      const opt = document.createElement('option');
      opt.value       = item.nombre;
      opt.textContent = item.nombre;
      filterSel.appendChild(opt);
    });

  // Conservar la selección previa si sigue existiendo en la lista
  if ([...filterSel.options].some(o => o.value === current)) {
    filterSel.value = current;
  }
}

// ============================================================
// UTILS FOR DURATION
// ============================================================
function parseDurationToMinutes(durStr) {
  if (!durStr) return 0;
  let total = 0;
  const matchH = durStr.match(/(\d+)h/);
  const matchM = durStr.match(/(\d+)min/);
  if (matchH) total += parseInt(matchH[1]) * 60;
  if (matchM) total += parseInt(matchM[1]);
  return total;
}

function formatMinutesToDuration(mins) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${h}h ${m.toString().padStart(2, '0')}min`;
}

function getNextDay(dayStr) {
  const idx = DAYS_ORDER.indexOf(dayStr);
  if (idx === -1) return dayStr;
  // Si es domingo (6), pasa al lunes (0), etc.
  const nextIdx = (idx + 1) % DAYS_ORDER.length;
  return DAYS_ORDER[nextIdx];
}

function getColaboradorMinutesOnDay(colabName, dayStr) {
  return allTasks
    .filter(t => t.colaborador === colabName && t.dia === dayStr)
    .reduce((sum, t) => sum + parseDurationToMinutes(t.duracion), 0);
}

// ============================================================
// SUBMIT — POST to Apps Script
// ============================================================
async function handleSubmit(e) {
  e.preventDefault();
  if (!validateForm()) {
    showToast('Completa todos los campos antes de guardar.', 'error');
    return;
  }
  if (!scriptUrl) { showConfigModal(); return; }

  const horas   = document.getElementById('duracionHoras').value;
  const minutos = document.getElementById('duracionMinutos').value;
  const duracion = `${horas}h ${minutos}min`;
  const duracionMins = parseInt(horas) * 60 + parseInt(minutos);

  const selectedDay = document.getElementById('dia').value;
  const colab = document.getElementById('colaborador').value;
  
  const payload = {
    action:      'add',
    token:       accessToken,
    area:        document.getElementById('area').value,
    actividad:   document.getElementById('actividad').value.trim(),
    dia:         selectedDay,
    prioridad:   parseInt(document.getElementById('prioridad').value),
    duracion:    duracion,
    colaborador: colab,
  };

  // Validar el límite de 8 horas (480 minutos)
  const currentMins = getColaboradorMinutesOnDay(colab, selectedDay);
  if (currentMins + duracionMins > 480) {
    // Pausar y mostrar modal
    pendingPayload = payload;
    document.getElementById('overloadMessage').innerHTML = 
      `El colaborador <strong>${escapeHtml(colab)}</strong> superará el límite de 8 horas diarias si asigna esta tarea el <strong>${selectedDay}</strong>.<br><br>Por favor, seleccione otro día:`;
    // Sugerir el día actual en el selector del modal
    document.getElementById('overloadNewDay').value = selectedDay;
    document.getElementById('overloadModal').removeAttribute('hidden');
    return; // Detener flujo
  }

  // Si no excede, guardar directo
  await executeSave(payload);
}

function cancelOverload() {
  document.getElementById('overloadModal').setAttribute('hidden', '');
  pendingPayload = null;
}

async function confirmOverload() {
  if (!pendingPayload) return;
  const newDay = document.getElementById('overloadNewDay').value;
  const duracionMins = parseDurationToMinutes(pendingPayload.duracion);
  
  // Validar si el nuevo día también está lleno
  const newDayMins = getColaboradorMinutesOnDay(pendingPayload.colaborador, newDay);
  if (newDayMins + duracionMins > 480) {
    showToast(`⚠️ ${pendingPayload.colaborador} también excede las 8h el ${newDay}. Elija otro.`, 'error');
    return;
  }

  // Actualizar día y guardar
  pendingPayload.dia = newDay;
  document.getElementById('overloadModal').setAttribute('hidden', '');
  await executeSave(pendingPayload);
  pendingPayload = null;
}

async function executeSave(payload) {
  const btn      = document.getElementById('submitBtn');
  const btnText  = btn.querySelector('.btn-text');
  const btnLoad  = btn.querySelector('.btn-loading');

  btn.disabled    = true;
  btnText.hidden  = true;
  btnLoad.hidden  = false;

  try {
    const res  = await fetch(scriptUrl, {
      method:  'POST',
      headers: { 'Content-Type': 'text/plain' },
      body:    JSON.stringify(payload),
    });
    const json = await res.json();

    if (json.status === 'ok') {
      showToast(`✅ Actividad guardada en Google Sheets (${payload.dia}).`, 'success');
      resetForm();
      updateStats();
      loadTasks();
    } else {
      throw new Error(json.message || 'Error desconocido del servidor.');
    }
  } catch (err) {
    console.error(err);
    showToast(`❌ Error al guardar: ${err.message}`, 'error');
  } finally {
    btn.disabled   = false;
    btnText.hidden = false;
    btnLoad.hidden = true;
  }
}

function resetForm() {
  // Reset all form fields
  document.getElementById('area').value = '';
  document.getElementById('actividad').value = '';
  document.getElementById('dia').value = '';
  document.getElementById('duracionHoras').value = '';
  document.getElementById('duracionMinutos').value = '';
  // Reset collaborator to first option
  const colSel = document.getElementById('colaborador');
  if (colSel.options.length > 0) colSel.selectedIndex = 0;
  // Reset priority
  document.getElementById('charCount').textContent = '0';
  document.querySelectorAll('.priority-btn').forEach(b => b.classList.remove('selected'));
  document.getElementById('prioridad').value = '';
  selectedPriority = null;
  document.querySelectorAll('.field-group').forEach(g => g.classList.remove('has-error'));
}

// ============================================================
// LOAD TASKS — GET from Apps Script
// ============================================================
async function loadTasks() {
  if (!scriptUrl) return;
  const content = document.getElementById('boardContent');
  const btn     = document.getElementById('refreshBtn');

  content.innerHTML = `<div class="loading-state"><div class="spinner large"></div><p>Cargando planificación...</p></div>`;
  if (btn) btn.disabled = true;

  try {
    const res  = await fetch(withToken(`${scriptUrl}?action=get`), { method: 'GET' });
    const json = await res.json();

    if (json.status === 'ok') {
      allTasks = json.data || [];
      renderBoard(allTasks);
      updateStats();
    } else {
      throw new Error(json.message || 'Error al obtener los datos.');
    }
  } catch (err) {
    console.error(err);
    content.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">⚠️</div>
        <p class="empty-title">No se pudo conectar con Google Sheets</p>
        <p class="empty-sub">${err.message}</p>
      </div>`;
    showToast('Error al cargar los datos. Verifique la URL del script.', 'error');
  } finally {
    if (btn) btn.disabled = false;
  }
}

// ============================================================
// RENDER BOARD
// ============================================================
function renderBoard(tasks) {
  const content       = document.getElementById('boardContent');
  const areaFilter    = document.getElementById('filterArea')?.value || '';
  const colabFilter   = document.getElementById('filterColaborador')?.value || '';
  const today         = getTodayName();

  const filtered = tasks.filter(t =>
    (!areaFilter  || t.area === areaFilter) &&
    (!colabFilter || t.colaborador === colabFilter)
  );

  if (filtered.length === 0) {
    content.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📋</div>
        <p class="empty-title">Sin actividades registradas</p>
        <p class="empty-sub">Agregue tareas desde la pestaña "Registrar Actividad".</p>
      </div>`;
    return;
  }

  // Group by day
  const grouped = {};
  DAYS_ORDER.forEach(d => { grouped[d] = []; });
  filtered.forEach(t => {
    if (grouped[t.dia]) grouped[t.dia].push(t);
  });

  // Sort each day by priority DESC
  DAYS_ORDER.forEach(d => {
    grouped[d].sort((a, b) => b.prioridad - a.prioridad);
  });

  let html = '';
  DAYS_ORDER.forEach(day => {
    const tasks = grouped[day];
    if (tasks.length === 0) return;
    const isToday = day === today;

    // Calcular totales diarios por colaborador para este día
    const dailyTotals = {};
    tasks.forEach(t => {
      if (t.colaborador && t.duracion) {
        if (!dailyTotals[t.colaborador]) dailyTotals[t.colaborador] = 0;
        dailyTotals[t.colaborador] += parseDurationToMinutes(t.duracion);
      }
    });

    let dailyColabHtml = '';
    const entries = Object.entries(dailyTotals).sort((a,b) => b[1] - a[1]);
    if (entries.length > 0) {
      dailyColabHtml = `<div class="daily-colab-summary">` + entries.map(([nombre, mins]) => {
        const isOverload = mins > 480; // Resaltar si pasa de 8h (480 min) en un solo día
        return `
          <span class="colab-stat-chip">
            <span class="colab-stat-name">${escapeHtml(nombre)}</span>
            <span class="colab-stat-time ${isOverload ? 'overload' : ''}">${formatMinutesToDuration(mins)}</span>
          </span>`;
      }).join('') + `</div>`;
    }

    html += `
      <div class="day-section">
        <div class="day-header">
          <div class="day-header-left">
            <div class="day-dot ${isToday ? 'today' : ''}"></div>
            <span class="day-name">${day}${isToday ? ' · Hoy' : ''}</span>
            <span class="day-count">${tasks.length} tarea${tasks.length !== 1 ? 's' : ''}</span>
          </div>
          ${dailyColabHtml}
        </div>
        <div class="tasks-grid">
          ${tasks.map(renderTaskCard).join('')}
        </div>
      </div>`;
  });

  content.innerHTML = html || `
    <div class="empty-state">
      <div class="empty-icon">📋</div>
      <p class="empty-title">Sin actividades para este filtro</p>
    </div>`;
}

function renderTaskCard(task) {
  const areaClass = {
    'Planta 1':               'area-p1',
    'Planta 2':               'area-p2',
    'Mantenimiento':          'area-mnt',
    'Seguridad/Medioambiente':'area-seg',
  }[task.area] || 'area-p1';

  const dateStr = task.fecha_creacion
    ? new Date(task.fecha_creacion).toLocaleDateString('es-ES', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })
    : '—';

  const colaboradorHtml = task.colaborador
    ? `<div class="task-chip">
         <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
         ${escapeHtml(task.colaborador)}
       </div>`
    : '';

  const duracionHtml = task.duracion
    ? `<div class="task-chip">
         <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
         ${escapeHtml(task.duracion)}
       </div>`
    : '';

  return `
    <article class="task-card prio-${task.prioridad}" role="article">
      <div class="task-top">
        <span class="task-area-badge ${areaClass}">${escapeHtml(task.area)}</span>
        <div class="task-top-right">
          <span class="task-prio-badge p${task.prioridad}" title="Prioridad ${task.prioridad}">${task.prioridad}</span>
          <button type="button" class="task-delete-btn" data-id="${escapeHtml(task.id)}" title="Eliminar actividad" aria-label="Eliminar actividad">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
          </button>
        </div>
      </div>
      <p class="task-desc">${escapeHtml(task.actividad)}</p>
      <div class="task-chips">
        ${colaboradorHtml}
        ${duracionHtml}
      </div>
      <div class="task-meta">
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
        Registrado: ${dateStr}
      </div>
    </article>`;
}

// ============================================================
// FILTER
// ============================================================
function applyFilter() {
  renderBoard(allTasks);
}

// ============================================================
// STATS
// ============================================================
function updateStats() {
  const total    = allTasks.length;
  const criticas = allTasks.filter(t => t.prioridad === 5).length;
  const p1count  = allTasks.filter(t => t.area === 'Planta 1').length;
  const p2count  = allTasks.filter(t => t.area === 'Planta 2').length;

  const grid = document.getElementById('statsGrid');
  grid.innerHTML = `
    <div class="stat-item"><span class="stat-num">${total}</span><span class="stat-lbl">Total</span></div>
    <div class="stat-item"><span class="stat-num" style="color:var(--p5)">${criticas}</span><span class="stat-lbl">Críticas</span></div>
    <div class="stat-item"><span class="stat-num" style="color:var(--area-p1)">${p1count}</span><span class="stat-lbl">Planta 1</span></div>
    <div class="stat-item"><span class="stat-num" style="color:var(--area-p2)">${p2count}</span><span class="stat-lbl">Planta 2</span></div>
  `;
}

// ============================================================
// CONFIG MODAL
// ============================================================
function showConfigModal() {
  const modal = document.getElementById('configModal');
  modal.removeAttribute('hidden');
}
function hideConfigModal() {
  const modal = document.getElementById('configModal');
  modal.setAttribute('hidden', '');
}
function saveConfig() {
  const input      = document.getElementById('scriptUrl').value.trim();
  const tokenInput = document.getElementById('scriptToken').value.trim();

  if (!input || !input.startsWith('https://script.google.com')) {
    showToast('Por favor ingrese una URL válida de Google Apps Script.', 'error');
    return;
  }
  if (!tokenInput) {
    showToast('Por favor ingrese el token de acceso configurado en Code.gs.', 'error');
    return;
  }

  scriptUrl   = input;
  accessToken = tokenInput;
  localStorage.setItem(CONFIG_KEY, scriptUrl);
  localStorage.setItem(TOKEN_KEY, accessToken);
  hideConfigModal();
  showToast('✅ Configuración guardada. Conectando con Google Sheets...', 'success');
  loadColaboradores();
  loadTasks();
}

// ============================================================
// TOAST
// ============================================================
function showToast(message, type = 'info') {
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span class="toast-icon">${icons[type] || 'ℹ️'}</span><span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(20px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 320);
  }, 4000);
}

// ============================================================
// UTILS
// ============================================================
function escapeHtml(str) {
  const map = { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#039;' };
  return String(str).replace(/[&<>"']/g, m => map[m]);
}
