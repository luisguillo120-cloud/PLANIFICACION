// ============================================================
// PlanificaPlanta — Code.gs
// Google Apps Script — Backend para la planificación semanal
//
// INSTRUCCIONES DE DESPLIEGUE:
//   1. En Google Sheets: Extensiones → Apps Script
//   2. Pegar este código en Code.gs
//   3. Cambiar el valor de ACCESS_TOKEN (más abajo) por un token propio
//   4. Implementar → Nueva implementación → Aplicación web
//      - Ejecutar como: Yo
//      - Quién tiene acceso: Cualquier usuario (o "Usuarios de tu organización")
//   5. Copiar la URL y pegarla en la aplicación web, junto con el
//      mismo ACCESS_TOKEN que configuró en el paso 3
// ============================================================

// ============================================================
// CONFIGURACIÓN — Cambie el nombre de la hoja si es diferente
// ============================================================
var SHEET_NAME = 'Planificacion';

// Límite de horas diarias por colaborador (en minutos). 8h = 480 min.
var LIMITE_MINUTOS_DIA = 480;

// ============================================================
// SEGURIDAD — Token de acceso compartido
// ------------------------------------------------------------
// Cambie este valor por uno propio antes de implementar (letras,
// números, sin espacios). Debe coincidir con el token que se
// ingresa en el modal de configuración del frontend.
// Cualquiera con la URL pero SIN este token no podrá leer ni
// escribir datos.
// ============================================================
var ACCESS_TOKEN = 'CAMBIA-ESTE-TOKEN-2026';

function isTokenValid(token) {
  return ACCESS_TOKEN && token === ACCESS_TOKEN;
}

// ============================================================
// GET — Leer tareas
// ============================================================
function doGet(e) {
  try {
    var params = (e && e.parameter) ? e.parameter : {};
    var action = params.action || 'get';

    if (!isTokenValid(params.token)) {
      return buildResponse({ status: 'error', message: 'No autorizado. Token de acceso inválido.' });
    }

    if (action === 'get') {
      var data = getTasks();
      return buildResponse({ status: 'ok', data: data });
    }

    if (action === 'colaboradores') {
      var nombres = getColaboradores();
      return buildResponse({ status: 'ok', data: nombres });
    }

    return buildResponse({ status: 'error', message: 'Acción no reconocida.' });

  } catch (err) {
    return buildResponse({ status: 'error', message: err.message });
  }
}

// ============================================================
// POST — Guardar/eliminar tarea
// ============================================================
function doPost(e) {
  try {
    var body   = JSON.parse(e.postData.contents);
    var action = body.action || 'add';

    if (!isTokenValid(body.token)) {
      return buildResponse({ status: 'error', message: 'No autorizado. Token de acceso inválido.' });
    }

    if (action === 'add') {
      var id = addTask(body);
      return buildResponse({ status: 'ok', id: id, message: 'Tarea guardada correctamente.' });
    }

    if (action === 'delete') {
      deleteTask(body.id);
      return buildResponse({ status: 'ok', message: 'Tarea eliminada.' });
    }

    return buildResponse({ status: 'error', message: 'Acción no reconocida.' });

  } catch (err) {
    return buildResponse({ status: 'error', message: err.message });
  }
}

// ============================================================
// HELPERS
// ============================================================

/**
 * Obtiene la hoja de cálculo. La crea con encabezados si no existe.
 */
function getSheet() {
  var ss    = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(SHEET_NAME);

  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    sheet.appendRow(['ID', 'Fecha_Creacion', 'Area', 'Actividad', 'Dia_Semana', 'Prioridad', 'Duracion', 'Colaborador']);
    sheet.getRange(1, 1, 1, 8).setFontWeight('bold');
    sheet.setFrozenRows(1);
    sheet.setColumnWidth(1, 200);  // ID
    sheet.setColumnWidth(2, 180);  // Fecha
    sheet.setColumnWidth(3, 160);  // Area
    sheet.setColumnWidth(4, 400);  // Actividad
    sheet.setColumnWidth(5, 120);  // Dia
    sheet.setColumnWidth(6, 90);   // Prioridad
    sheet.setColumnWidth(7, 100);  // Duracion
    sheet.setColumnWidth(8, 180);  // Colaborador
  }
  return sheet;
}

/**
 * Genera un ID único tipo UUID simplificado.
 */
function generateId() {
  return Utilities.getUuid();
}

/**
 * Lee todas las tareas y las devuelve como array de objetos.
 */
function getTasks() {
  var sheet  = getSheet();
  var values = sheet.getDataRange().getValues();

  if (values.length <= 1) return []; // Solo encabezados o vacía

  var tasks = [];

  for (var i = 1; i < values.length; i++) {
    var row = values[i];
    if (!row[0]) continue; // Saltear filas vacías

    tasks.push({
      id:              String(row[0]),
      fecha_creacion:  row[1] ? new Date(row[1]).toISOString() : null,
      area:            String(row[2]),
      actividad:       String(row[3]),
      dia:             String(row[4]),
      prioridad:       parseInt(row[5]) || 1,
      duracion:        row[6] ? String(row[6]) : '',
      colaborador:     row[7] ? String(row[7]) : '',
    });
  }
  return tasks;
}

/**
 * Convierte un texto de duración tipo "2h 30min" a minutos totales.
 * Replica la misma lógica del frontend (app.js) para poder validar
 * el límite diario también en el servidor.
 * @param {string} durStr
 * @returns {number}
 */
function parseDurationToMinutes(durStr) {
  if (!durStr) return 0;
  var total = 0;
  var matchH = String(durStr).match(/(\d+)h/);
  var matchM = String(durStr).match(/(\d+)min/);
  if (matchH) total += parseInt(matchH[1], 10) * 60;
  if (matchM) total += parseInt(matchM[1], 10);
  return total;
}

/**
 * Suma los minutos ya asignados a un colaborador en un día dado,
 * leyendo directamente la hoja (no confía en el frontend).
 * @param {string} colaborador
 * @param {string} dia
 * @returns {number} minutos totales ya asignados
 */
function getMinutosAsignados(colaborador, dia) {
  var tasks = getTasks();
  var total = 0;
  for (var i = 0; i < tasks.length; i++) {
    if (tasks[i].colaborador === colaborador && tasks[i].dia === dia) {
      total += parseDurationToMinutes(tasks[i].duracion);
    }
  }
  return total;
}

/**
 * Agrega una nueva tarea a la hoja de cálculo.
 * Usa LockService para evitar condiciones de carrera si dos personas
 * guardan al mismo tiempo, y valida el límite de 8h/día en el
 * servidor (no solo confía en la validación del frontend).
 * @param {Object} data - { area, actividad, dia, prioridad, duracion, colaborador }
 * @returns {string} ID de la nueva tarea
 */
function addTask(data) {
  // Validaciones básicas
  if (!data.area)        throw new Error('El campo "area" es requerido.');
  if (!data.actividad)   throw new Error('El campo "actividad" es requerido.');
  if (!data.dia)         throw new Error('El campo "dia" es requerido.');
  if (!data.prioridad)   throw new Error('El campo "prioridad" es requerido.');
  if (!data.colaborador) throw new Error('El campo "colaborador" es requerido.');

  var validAreas = ['Planta 1', 'Planta 2', 'Mantenimiento', 'Seguridad/Medioambiente'];
  if (validAreas.indexOf(data.area) === -1) throw new Error('Área no válida.');

  var prioridad = parseInt(data.prioridad);
  if (prioridad < 1 || prioridad > 5) throw new Error('Prioridad debe estar entre 1 y 5.');

  var validDias = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
  if (validDias.indexOf(data.dia) === -1) throw new Error('Día no válido.');

  var colaborador   = String(data.colaborador).trim();
  var duracion      = data.duracion ? String(data.duracion).trim() : '';
  var duracionMins  = parseDurationToMinutes(duracion);

  var lock = LockService.getScriptLock();
  lock.waitLock(30000); // hasta 30s esperando el turno

  try {
    // Re-validar el límite de 8h leyendo el estado actual de la hoja,
    // dentro del lock, para que dos guardados simultáneos no se salten
    // el límite (el frontend ya avisa antes, esto es el respaldo real).
    if (duracionMins > 0) {
      var minutosPrevios = getMinutosAsignados(colaborador, data.dia);
      if (minutosPrevios + duracionMins > LIMITE_MINUTOS_DIA) {
        throw new Error(
          'El colaborador "' + colaborador + '" superaría el límite de 8 horas el ' +
          data.dia + ' (ya tiene ' + formatMinutes(minutosPrevios) +
          ' asignados). Elija otro día u otro colaborador.'
        );
      }
    }

    var id    = generateId();
    var fecha = new Date();
    var sheet = getSheet();

    sheet.appendRow([
      id,
      fecha,
      data.area,
      String(data.actividad).trim(),
      data.dia,
      prioridad,
      duracion,
      colaborador,
    ]);

    return id;
  } finally {
    lock.releaseLock();
  }
}

function formatMinutes(mins) {
  var h = Math.floor(mins / 60);
  var m = mins % 60;
  return h + 'h ' + (m < 10 ? '0' + m : m) + 'min';
}

/**
 * Lee los colaboradores desde la hoja "Colaboradores".
 * Lee columna A (Nombre) y columna B (Puesto) si existe.
 * Detecta automáticamente si la fila 1 es encabezado.
 * @returns {Array<Object>} Lista de { nombre, puesto }
 */
function getColaboradores() {
  var ss    = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName('Colaboradores');

  if (!sheet) {
    throw new Error('No se encontró la hoja "Colaboradores" en el archivo.');
  }

  var lastRow = sheet.getLastRow();
  var lastCol = sheet.getLastColumn();
  if (lastRow < 1 || lastCol < 1) return [];

  // Leer todas las filas con datos
  var values = sheet.getRange(1, 1, lastRow, Math.max(lastCol, 2)).getValues();
  if (values.length === 0) return [];

  // Detectar si fila 1 es encabezado: si la celda A1 NO parece un nombre propio
  // (encabezados suelen ser: "Nombre", "Colaborador", "Nombres", "NOMBRE", etc.)
  var firstCell = String(values[0][0]).trim().toLowerCase();
  var esEncabezado = (firstCell === 'nombre' || firstCell === 'colaborador' ||
                      firstCell === 'nombres' || firstCell === 'nombre completo' ||
                      firstCell === 'empleado' || firstCell === 'trabajador');
  var startRow = esEncabezado ? 1 : 0;

  var colaboradores = [];
  for (var i = startRow; i < values.length; i++) {
    var nombre = String(values[i][0]).trim();
    var puesto = values[i].length > 1 ? String(values[i][1]).trim() : '';
    if (nombre) {
      colaboradores.push({ nombre: nombre, puesto: puesto });
    }
  }

  return colaboradores;
}

/**
 * Elimina una tarea por ID.
 * @param {string} id - ID de la tarea a eliminar
 */
function deleteTask(id) {
  if (!id) throw new Error('ID requerido para eliminar.');

  var lock = LockService.getScriptLock();
  lock.waitLock(30000);

  try {
    var sheet  = getSheet();
    var values = sheet.getDataRange().getValues();

    for (var i = 1; i < values.length; i++) {
      if (String(values[i][0]) === String(id)) {
        sheet.deleteRow(i + 1);
        return;
      }
    }
    throw new Error('Tarea no encontrada con ID: ' + id);
  } finally {
    lock.releaseLock();
  }
}

/**
 * Construye la respuesta JSON con encabezados CORS correctos.
 */
function buildResponse(data) {
  var output = ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
  return output;
}
