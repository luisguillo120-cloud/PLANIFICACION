# 📋 Instrucciones de Configuración — PlanificaPlanta

## Arquitectura General

```
[Navegador Web] ──POST/GET──▶ [Google Apps Script Web App] ──▶ [Google Sheets]
```

---

## PASO 1 — Crear la Hoja de Google Sheets

1. Abra [Google Sheets](https://sheets.google.com) y cree una nueva hoja de cálculo.
2. Asígnele un nombre descriptivo, por ejemplo: **"PlanificaPlanta - BD"**.
3. **El Apps Script creará automáticamente la hoja interna** llamada `Planificacion` con sus encabezados la primera vez que se ejecute. No es necesario hacerlo manualmente.

> **Opcional (verificación):** Después de desplegar, si desea verificar, la hoja `Planificacion` tendrá las columnas:
> `ID | Fecha_Creacion | Area | Actividad | Dia_Semana | Prioridad`

---

## PASO 2 — Configurar Google Apps Script

### 2.1 Abrir el editor de Apps Script

Con la hoja de Google Sheets abierta:
1. En el menú superior, haga clic en **Extensiones**
2. Seleccione **Apps Script**
3. Se abrirá el editor en una nueva pestaña

### 2.2 Pegar el código

1. En el editor, haga clic en el archivo **`Code.gs`** (en el panel izquierdo)
2. **Seleccione todo** el contenido existente (Ctrl+A) y **bórrelo**
3. **Copie y pegue** el contenido completo del archivo `Code.gs` que se encuentra en esta carpeta
4. Haga clic en el ícono de **guardar** (💾) o presione **Ctrl+S**

### 2.3 Configurar el manifest (appsscript.json)

1. En el panel izquierdo, haga clic en **⚙️ Configuración del proyecto**
2. Active la opción **"Mostrar el archivo de manifiesto appsscript.json en el editor"**
3. Vuelva al editor y haga clic en **`appsscript.json`**
4. Reemplace su contenido con el del archivo `appsscript.json` de esta carpeta
5. Ajuste `"timeZone"` a su zona horaria si es diferente:
   - México: `"America/Mexico_City"`
   - Colombia/Perú/Ecuador: `"America/Lima"`
   - Argentina: `"America/Argentina/Buenos_Aires"`
   - Chile: `"America/Santiago"`
   - Venezuela: `"America/Caracas"`
6. Guarde con **Ctrl+S**

### 2.4 🔒 Configurar el token de acceso (IMPORTANTE)

Por seguridad, el backend ahora exige un **token de acceso**: sin él, nadie puede leer ni escribir datos aunque conozca la URL de la aplicación.

1. En `Code.gs`, busque la línea:
   ```javascript
   var ACCESS_TOKEN = 'CAMBIA-ESTE-TOKEN-2026';
   ```
2. Reemplace el valor por uno propio (letras y números, sin espacios). Ejemplo: `'planta-norte-8f2k91'`
3. Guarde con **Ctrl+S**
4. **Anote este token** — lo va a necesitar en el Paso 4 para conectar el frontend.

> Si más adelante quiere revocar el acceso a todos los usuarios (por ejemplo, si el token se filtró), simplemente cambie este valor y vuelva a implementar (Paso 3). Cada usuario deberá ingresar el nuevo token en su navegador.

---

## PASO 3 — Desplegar como Aplicación Web

1. En el editor de Apps Script, haga clic en el botón **"Implementar"** (esquina superior derecha)
2. Seleccione **"Nueva implementación"**
3. Haga clic en **⚙️ (configuración)** junto a "Seleccionar tipo" y elija **"Aplicación web"**
4. Complete la configuración:

   | Campo | Valor recomendado |
   |-------|-------------------|
   | **Descripción** | `PlanificaPlanta v1` |
   | **Ejecutar como** | `Yo (tu-email@gmail.com)` |
   | **Quién tiene acceso** | `Cualquier usuario` *(ver nota abajo)* |

5. Haga clic en **"Implementar"**
6. **Otorgue los permisos** cuando se le solicite (haga clic en "Autorizar acceso", seleccione su cuenta y acepte)
7. **COPIE la URL** que aparece — se verá así:
   ```
   https://script.google.com/macros/s/AKfycby.../exec
   ```

> **Nota sobre acceso:** Si la aplicación es solo para uso personal o de su empresa con Google Workspace, puede seleccionar "Usuarios de tu organización" para mayor seguridad.

---

## PASO 4 — Conectar el Frontend

### Opción A — Usando los archivos localmente

1. Abra el archivo `index.html` en su navegador
2. Al cargarse por primera vez, aparecerá un **modal de configuración**
3. Pegue la URL del Apps Script obtenida en el Paso 3
4. Pegue también el **Token de Acceso** que configuró en el Paso 2.4
5. Haga clic en **"Guardar y Conectar"**
6. ✅ La aplicación se conectará automáticamente a Google Sheets

> Cada persona que use la aplicación necesita ingresar la URL **y** el token la primera vez que abre `index.html` en su navegador (se guarda localmente después de eso).

### Opción B — Hosting en GitHub Pages (gratuito)

1. Cree un repositorio en [GitHub](https://github.com)
2. Suba los archivos `index.html`, `style.css` y `app.js`
3. En el repositorio: **Settings → Pages → Branch: main → Save**
4. Su app estará disponible en `https://[usuario].github.io/[repositorio]`

### Opción C — Hosting en Google Drive

1. Suba los archivos a una carpeta en Google Drive
2. Comparta la carpeta como "cualquier persona con el enlace puede ver"
3. Use la URL de visualización de Google Drive

---

## PASO 5 — Verificar el Funcionamiento

### Test 1: Guardar una tarea
1. Vaya a la pestaña **"Registrar Actividad"**
2. Complete todos los campos del formulario
3. Haga clic en **"Guardar Actividad"**
4. Debe aparecer el mensaje: ✅ "Actividad guardada correctamente en Google Sheets"
5. Verifique en Google Sheets que la fila se agregó

### Test 2: Ver el tablero
1. Vaya a la pestaña **"Planificación Semanal"**
2. Las tareas deben aparecer agrupadas por día y ordenadas por prioridad (5 primero)
3. Use el filtro de área y el filtro de colaborador (pueden combinarse) para verificar el filtrado

### Test 3: Eliminar una tarea
1. En cualquier tarjeta de tarea, haga clic en el ícono de basurero (🗑️) en la esquina superior derecha
2. Confirme la eliminación en el cuadro de diálogo
3. La tarea debe desaparecer del tablero y de la hoja de Google Sheets

### Test 4: Límite de 8 horas (validación en servidor)
1. Asigne varias tareas al mismo colaborador y al mismo día hasta acercarse a las 8 horas
2. Al intentar exceder el límite, debe aparecer el modal para elegir otro día
3. Esta validación ahora también ocurre en el servidor, por lo que es segura incluso si dos personas guardan al mismo tiempo

---

## Solución de Problemas

### ❌ "Error al guardar" o "Error al cargar"
- Verifique que la URL del script sea correcta (debe terminar en `/exec`)
- Asegúrese de haber **re-desplegado** después de cualquier cambio al código
- Verifique que los permisos fueron otorgados correctamente

### ❌ "No autorizado" o error 403
- En el Apps Script, vaya a **Implementar → Administrar implementaciones**
- Edite la implementación y cambie el acceso a "Cualquier usuario"
- Haga clic en **"Implementar"** para aplicar el cambio

### ❌ "No autorizado. Token de acceso inválido."
- El token ingresado en el modal de configuración no coincide con `ACCESS_TOKEN` en `Code.gs`
- Verifique que copió el token exactamente (sin espacios extra) en ambos lugares
- Si cambió el token en `Code.gs` después de que otros ya configuraron la app, cada uno debe volver a ingresarlo

### ❌ El modal no desaparece
- Verifique en la consola del navegador (F12) si hay errores de red
- Asegúrese de que la URL pegada comience con `https://script.google.com/macros/s/`
- Asegúrese de haber ingresado también el token de acceso

### ❌ Cambiar la URL o el token del script después de configurados
- Abra la consola del navegador (F12 → Console)
- Ejecute:
  ```javascript
  localStorage.removeItem('planificaplanta_script_url');
  localStorage.removeItem('planificaplanta_access_token');
  ```
- Recargue la página — aparecerá nuevamente el modal de configuración

---

## Re-despliegue (Actualizaciones futuras)

Cuando modifique el código `Code.gs`:
1. En el editor de Apps Script: **Implementar → Administrar implementaciones**
2. Seleccione la implementación existente y haga clic en **✏️ Editar**
3. En "Versión", seleccione **"Nueva versión"**
4. Haga clic en **"Implementar"**
5. La URL del script **NO cambia** — no es necesario reconfigurar el frontend

---

## Estructura de Archivos del Proyecto

```
PLANIFICACION/
├── index.html          ← Interfaz principal (abrir en navegador)
├── style.css           ← Estilos del dashboard
├── app.js              ← Lógica del frontend
├── Code.gs             ← Backend Google Apps Script
├── appsscript.json     ← Configuración del proyecto Apps Script
└── INSTRUCCIONES.md    ← Este archivo
```

---

*PlanificaPlanta — Desarrollado para coordinación de planta manufacturera*
